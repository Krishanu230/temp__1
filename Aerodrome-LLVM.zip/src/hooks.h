#include <pthread.h>

// called just after acquiring lock
void enter_critical_section(void *addr);
// called just before releasing lock
void exit_critical_section(void *addr);

// called before writing to addr
void writeHook(void* addr);
// called before reading from addr
void readHook(void* addr);

// first call in main
void initHook();
// last call in main
void exitHook();

// first call in thread's func
void enter_thread(pthread_t tid, pthread_t ptid);
// first call immediately after pthread_join in parent thread
void exit_thread(pthread_t tid, pthread_t ctid);




