#include "vc.h"
#include <iostream>

//Set of vector clocks per thread bunched together in one class.
class ADThClocks {
  public :
    ADThClocks();
    ADThClocks(int dim);
    VectorClock clockThread;
    VectorClock clockThreadBegin;
    friend ostream& operator<<(ostream& os, const ADThClocks& clocks);
};

ADThClocks::ADThClocks(int dim): clockThread(dim), clockThreadBegin(dim) {

}

ADThClocks::ADThClocks(): clockThread(0), clockThreadBegin(0){

}

ostream& operator<<(ostream& os, const ADThClocks&  clocks){
  os << "clockThread: " << clocks.clockThread << " clockThreadBegin: " << clocks.clockThreadBegin;
  return os;
}
