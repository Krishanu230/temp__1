#include "vc.h"
#include <iostream>

//Set of vector clocks per variable bunched together in one class.
class ADVarClocks {
  public :
    ADVarClocks();
    ADVarClocks(int dim);
    VectorClock read;
    VectorClock write;
    VectorClock readcheck;
    friend ostream& operator<<(ostream& os, const ADVarClocks& clocks);
};

ADVarClocks::ADVarClocks(int dim): read(dim), write(dim), readcheck(dim) {

}

ADVarClocks::ADVarClocks(): read(0), write(0), readcheck(0) {

}

ostream& operator<<(ostream& os, const ADVarClocks&  clocks){
  os << "Read Clock: " << clocks.read << " Write Clock: " << clocks.write << " readcheck Clock: " << clocks.readcheck;
  return os;
}
