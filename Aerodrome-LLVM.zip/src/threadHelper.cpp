#include <iostream>
#include <unordered_map>
#include <string>
#include <mutex>
#include <condition_variable>
#include <vector>
#include <unistd.h>
#include <pthread.h>
#include <thread>
#include <unistd.h>
#include "hooks.h"

using namespace std;

unordered_map<string,pthread_t> g_ptid; // index by function name
// to handle multiple threads created using same function
unordered_map<string,mutex> g_mutex;
unordered_map<string,condition_variable> g_cv;
unordered_map<string,bool> g_ready;

void threadCreated_parent(char *k1) {
     string k = k1;
     unique_lock<mutex> ul(g_mutex[k]);
     g_cv[k].wait(ul, [k]() { return g_ready[k] == false; });
     g_ptid[k] = pthread_self();
     // cout<<"threadCreated_parent: "<<g_ptid[k]<<"\n";
     g_ready[k] = true;
     ul.unlock();
     g_cv[k].notify_one();
}

void threadCreated_child(char *k1) {
     string k = k1;
     unique_lock<mutex> ul(g_mutex[k]);
     g_cv[k].wait(ul, [k]() { return g_ready[k]; });
     enter_thread(pthread_self(),g_ptid[k]);
     g_ready[k] = false;
     ul.unlock();
     g_cv[k].notify_one();
}

void threadJoined(pthread_t ctid) {
	exit_thread(pthread_self(),ctid);
}