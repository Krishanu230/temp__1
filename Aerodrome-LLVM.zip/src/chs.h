#include <iostream>
#include "oneapi/tbb/concurrent_set.h"


using namespace oneapi::tbb;
using namespace std;

template<typename K>
class Concurrent_Set {
  public:
     virtual void put(K) = 0;
     virtual bool find(K) = 0;
     virtual void remove(K) = 0;
     virtual void print() = 0;
     virtual ~Concurrent_Set() = default;
};

template<typename K>
class TBBSet: public Concurrent_Set<K>{
  public:
    TBBSet(){
      cout<<"in tbb set cons"<<endl;
    };

    void put(K key){
      const auto pair = set.insert(key);
      if (pair.second == true) {
        cout<<" set   - Insert successfull"<<endl;
      }
      else {
        cout<<" set   - Insert failed"<<endl;
      }
    };

    bool find(K key){
      return set.contains(key);
      //return true;
    };

    void remove(K key){
      auto itemIsDel = set.unsafe_erase(key);
    };

    void print(){
      for(typename concurrent_set<K>::iterator i = set.begin(); i!=set.end();++i){
        cout<<*i<<" ";
      }
    }
  private:
    tbb::concurrent_set<K> set;

};

template<typename K>
Concurrent_Set<K>* makeCS(){
  return new TBBSet<K>();
//return NULL;
};
