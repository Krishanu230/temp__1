#include <iostream>
#include "oneapi/tbb/concurrent_hash_map.h"


using namespace oneapi::tbb;
using namespace std;

template<typename K,typename V>
class Concurrent_Hashmap {
  public:
     virtual void put(K, V) = 0;
     virtual V get(K) = 0;
     virtual bool find(K) = 0;
     virtual void remove(K) = 0;
     virtual void print() = 0;
     virtual ~Concurrent_Hashmap() = default;
};

template<typename K,typename V>
class TBBHashMap: public Concurrent_Hashmap<K,V>{
  public:
    TBBHashMap(){
      cout<<"in tbb cons"<<endl;
    };

    void put(K key, V value){
      typename tbb::concurrent_hash_map<K, V>::accessor WriteAcc;
      cout<<"1"<<endl;
      const auto itemIsNew = dict.insert(WriteAcc, key);
      cout<<"2"<<endl;
      if (itemIsNew == true) {
        cout<<" input   - Insert"<<endl;
        WriteAcc->second = value;
      }
      else {
        cout<<" input   - Update"<<endl;
        WriteAcc->second = value;
      }
      cout<<"3"<<endl;
      //cout<<"  inget  - "<<*(WriteAcc->first)<<": "<<WriteAcc->second<<endl;
      cout<<"4"<<endl;
    };

    V get(K key){
      typename tbb::concurrent_hash_map<K, V>::const_accessor ReadAcc;
      const auto isFound = dict.find(ReadAcc, key);
      if (isFound == true) {
        //cout<<"  inget  - "<<*(ReadAcc->first)<<": "<<ReadAcc->second<<" also key is "<<*key<<endl;
      }
      return ReadAcc->second;
      //return NULL;
    };

    bool find(K key){
      typename tbb::concurrent_hash_map<K, V>::const_accessor ReadAcc;
      return dict.find(ReadAcc, key);
      //return true;
    };

    void remove(K key){
      auto itemIsDel = dict.erase(key);
    };

    void print(){
      for(typename concurrent_hash_map<K, V>::iterator i = dict.begin(); i!=dict.end();++i){
        //cout<<*(i->first)<<" ";
        //cout<<*(i->second)<<endl;
      }
    }
  private:
    tbb::concurrent_hash_map<K, V> dict;

};

template<typename K,typename V>
Concurrent_Hashmap<K,V>* makeCHM(){
  return new TBBHashMap<K, V>();
//return NULL;
};
