#include <iostream>
#include "oneapi/tbb/concurrent_hash_map.h"

using namespace std;
using namespace oneapi::tbb;

//Ref: https://link.springer.com/content/pdf/10.1007%2F978-1-4842-4398-5.pdf
int main(int argc, char const *argv[]) {
  concurrent_hash_map<int, int>  StringTable;
  concurrent_hash_map<int, int> ::accessor a;
  StringTable.insert(a, 1);
  StringTable.insert(a, 2);
  StringTable.insert(a, 3);
  StringTable.insert(a, 4);
  StringTable.insert(a, 5);
  StringTable.insert({6,6666});
  a.release();
  for(concurrent_hash_map<int, int>::iterator i = StringTable.begin(); i!=StringTable.end();++i){
    cout<<i->first<<" ";
    cout<<i->second<<endl;
  }
  return 0;
}
