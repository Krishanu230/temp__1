#include <iostream>
#include "hooks.h"
#include "vc.h"
#include "chm.h"
#include "chs.h"
#include "advc.h"
#include "adtc.h"
#include <vector>
#include <memory>
#include <any>

using namespace std;

/*List of ds required for aerodrome
  1. Per Thread: Two Vector Clocks.
  2. Per Variable: Three Vector Clocks.
  3. A Store of all the thread objects and memory variable to iterate over.
  4. Lock to Thread, Variable to Thread, Thread to Integer Hashmap.
*/

int INIT_VECTOR_CLOCK_SIZE = 16;

//Breaking up the ShadowVar-to-int map into the two following maps:
Concurrent_Hashmap<void*, ADVarClocks*>* varToShadowVar = makeCHM<void*, ADVarClocks*>();
Concurrent_Hashmap<void*, int>* varsTrack = makeCHM<void*, int>();
int nVars;

int nThreads;
Concurrent_Hashmap<int, ADThClocks*>* TidToShadowTh = makeCHM<int, ADThClocks*>();
//var-to-shadowThread map -> var-to-tid map
Concurrent_Hashmap<void*, int>* varToTid = makeCHM<void*, int>();
//Shadow-Thread to integer map -> Tid to integer map
Concurrent_Hashmap<int, int>* nestingofThreads = makeCHM<int, int>();

Concurrent_Set<int>* tidSet = makeCS<int>();
Concurrent_Set<void*>* varSet = makeCS<void*>();

void enter_critical_section(void *addr) {
  // cout<<"enter-cs\n";
}

void exit_critical_section(void *addr) {
  // cout<<"exit-cs\n";
}

void writeHook(void* addr) {
  // cout<<"write\n";
}

void readHook(void* addr) {
   cout<<"read\n";
   int tid = pthread_self();
   VectorClock C_t = TidToShadowTh->get(tid)->clockThread;
}

void initHook() {
   cout<<"init\n";
   nVars = 0;

}

void exitHook() {
  // cout<<"exit\n";
}

void enter_thread(pthread_t tid, pthread_t ptid) {
  // cout<<"Thread: "<<tid<<" created by "<<ptid<<"\n";
}

void exit_thread(pthread_t tid, pthread_t ctid) {
  // cout<<"Thread: "<<tid<<" joined by "<<ctid<<"\n";
}

int main(int argc, char const *argv[]) {

  return 0;
}
