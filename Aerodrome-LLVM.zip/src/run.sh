#!/usr/bin/env bash

clang++ -O0 -fno-use-cxa-atexit -pthread -S -emit-llvm "${1}.cpp"
opt -enable-new-pm=0 -load ../llvm-project/build/lib/MH.so -MH <"${1}".ll >t1.ll # memory hooks
opt -enable-new-pm=0 -load ../llvm-project/build/lib/CS_PASS.so -CS <t1.ll >t2.ll # enter and exit critical section hooks
opt -enable-new-pm=0 -load ../llvm-project/build/lib/THREAD_PASS.so -THREAD <t2.ll >t3.ll # enter and exit thread
clang++ -O0 -fno-use-cxa-atexit -pthread -S -emit-llvm threadHelper.cpp
clang++ -O0 -fno-use-cxa-atexit -I oneapi-tbb/include -L oneapi-tbb/lib/intel64/gcc4.8/ -ltbb -pthread -S -emit-llvm hooks.cpp
llvm-link t3.ll hooks.ll threadHelper.ll -S -o=t4.ll
opt -enable-new-pm=0 -load ../llvm-project/build/lib/EX.so -EX <t4.ll >t5.ll # init and exit hooks
lli t5.ll # run

# cleanup
# rm *.ll
