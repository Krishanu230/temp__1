#include <pthread.h>
#include <iostream>
#include <unistd.h>

using namespace std;

void* f1(void* arg){
    pthread_exit(NULL);
}

void* f2(void* arg){
    pthread_exit(NULL);
}
  
int main()
{
    pthread_t ptid1,ptid12,ptid2;
  
    pthread_create(&ptid1, NULL, &f1, NULL);
    pthread_create(&ptid2, NULL, &f2, NULL);
    // pthread_create(&ptid12, NULL, &f1, NULL);

    pthread_join(ptid1, NULL);
    pthread_join(ptid2, NULL);
    // pthread_join(ptid12, NULL);
  
    return 0;
}