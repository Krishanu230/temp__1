#ifndef VC_H
#define VC_H

#include <vector>
#include <iostream>
#include<string>

using namespace std;
class VectorClock {
  public:
    VectorClock(int dim);
    int Get(int tid) const;
    void Set(int tid, int v);
    string Print();

    bool operator==(const VectorClock& other);
    bool operator<=(const VectorClock& other);
    void operator=(const VectorClock& other);
    void operator=(int value);
    friend ostream& operator<<(ostream& os, const VectorClock& clock);

  private:
    std::vector<int> vc;
};

int VectorClock::Get(int tid) const {
  return vc[tid];
}

void VectorClock::Set(int tid, int v) {
  vc[tid] = v;
}

bool VectorClock::operator==(const VectorClock& other){
  vector<int> thisVC = vc;
  vector<int> otherVC = other.vc;
  return thisVC == otherVC;
}

bool VectorClock::operator<=(const VectorClock& other){
  vector<int> thisVC = vc;
  vector<int> otherVC = other.vc;

  int min = std::min(thisVC.size(), otherVC.size());
  for (int i =0; i<min; i++){
    if (otherVC[i] < thisVC[i]){
      return false;
    }
  }

  for (int i=min; i < thisVC.size(); i++){
    if (thisVC[i] != 0){
      return false;
    }
  }
  return true;
}

void VectorClock::operator=(const VectorClock& other){
  vector<int> otherVC = other.vc;

  //assuming thisVC.size() >= otherVC.size()
  for (int i =0; i<vc.size(); i++){
    vc[i] = other.vc[i];
  }

  for (int i=vc.size(); i < other.vc.size(); i++){
    vc[i] = 0;
  }
}

void VectorClock::operator=(int value){
  fill(vc.begin(), vc.end(), value);
}

VectorClock::VectorClock(int dim) : vc(dim, 0){
}

ostream& operator<<(ostream& os, const VectorClock& clock){
  for (auto i = clock.vc.begin(); i != clock.vc.end(); ++i){
    os << *i<<' ';
  }
  return os;
}

#endif
