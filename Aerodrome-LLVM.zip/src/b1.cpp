#include <iostream>
#include <mutex>
#include <thread>
#include <unistd.h>

using namespace std;

mutex m1Lock;
int m1Var = 0;

void func(int tid) {
  m1Lock.lock();
  m1Var = tid;
  m1Lock.unlock();
}

int main(void) {
  func(0);
  thread th1(func, 1);
  thread th2(func, 2);
  th1.join();
  th2.join();
  cout << "m1Var: " << m1Var << "\n";
  return 0;
}
