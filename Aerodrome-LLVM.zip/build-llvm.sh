#!/usr/bin/env bash

# This is to be run from the project root.

cd ./llvm-project
mkdir -p build
cd build
cmake -DCMAKE_EXPORT_COMPILE_COMMANDS=1 -DCMAKE_BUILD_TYPE=Release -DLLVM_ENABLE_ASSERTIONS=ON -DLLVM_INCLUDE_EXAMPLES=OFF -DLLVM_TARGETS_TO_BUILD="X86" -DLLVM_ENABLE_Z3_SOLVER=OFF -DCLANG_ENABLE_STATIC_ANALYZER=OFF -DCLANG_ENABLE_ARCMT=OFF -DLLVM_OPTIMIZED_TABLEGEN=ON -DLLVM_ENABLE_PROJECTS='clang;llvm-dis;llvm-link;lli;opt;clang-tools-extra;compiler-rt;' -G "Ninja" ../llvm
ninja -j8
export PATH=$PATH:$(pwd)/bin
cd ../../
