# AERODROME - [LLVM]
[Aerodrome](https://arxiv.org/pdf/2001.04961.pdf) implementation using LLVM suite for atomicity checking of C/C++ programs.

* Build LLVM
```
chmod +x ./build-llvm.sh
./build-llvm.sh
```
* Run Aerodrome
```
cd src
chmod +x ./run.sh
./run.sh {name of the target file without .cpp}
```
